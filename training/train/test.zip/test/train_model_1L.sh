#!/bin/bash
#SBATCH -J tr_nemo1l
#SBATCH -N 2
#SBATCH -n 2
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:2
#SBATCH -p small
#SBATCH --time=24:00:00
#SBATCH --output=slurm/%x_%j.out

# Ensure output directory for logs exists
mkdir -p slurm

# Defaults (override via env when submitting)
DATAMIX=${DATAMIX:-"/tmpdir/m24047brmn/nemo_1b/data/nemo1b_mock_datamix.json"}
OUTPUT_DIR=${OUTPUT_DIR:-"/tmpdir/m24047brmn/nemo_1b/output"}
NAME=${NAME:-"nemotron1b-1layer-test"}
SEED=${SEED:-1234}

# Compute MASTER_ADDR and MASTER_PORT on login node (where SLURM vars are set)
export MASTER_PORT=$(echo "${SLURM_JOB_ID:-0} % 100000 % 50000 + 10001" | bc)
export MASTER_ADDR=$(hostname --ip-address)

echo "=========================================="
echo "Starting Nemotron training (2 nodes x 2 GPUs)"
echo "Datamix:     $DATAMIX"
echo "Output:      $OUTPUT_DIR"
echo "Nodes:       $SLURM_NNODES"
echo "MASTER_ADDR: $MASTER_ADDR"
echo "MASTER_PORT: $MASTER_PORT"
echo "=========================================="

# Run inside the NeMo container via srun
srun apptainer exec \
    --env "PYTHONUSERBASE=${MYENVS}/nemo" \
    --env "MASTER_ADDR=${MASTER_ADDR}" \
    --env "MASTER_PORT=${MASTER_PORT}" \
    --env "SLURM_NNODES=${SLURM_NNODES}" \
    --bind /tmpdir,/work --nv /work/conteneurs/calmip/nemo_25.11_arm.sif \
    torchrun \
        --nnodes=${SLURM_NNODES} \
        --nproc_per_node=2 \
        --rdzv_id=${SLURM_JOB_ID} \
        --rdzv_backend=c10d \
        --rdzv_endpoint="${MASTER_ADDR}:${MASTER_PORT}" \
        /work/m24047/m24047brmn/nemo/OpenLLM-BPI-Training/training/train/test/train_model_1L.py \
        --datamix $DATAMIX \
        --output_dir $OUTPUT_DIR \
        --name $NAME \
        --arch nemotron1b \
        --max_steps 5000 \
        --num_nodes ${SLURM_NNODES} \
        --gpus_per_node 2 \
        --tensor_parallelism 1 \
        --pipeline_parallelism 1 \
        --context_parallelism 1 \
        --generate_every_n_steps 0 \
        --generate_prompt "The future of artificial intelligence is" \
        --generate_max_tokens 64 \
        --seed $SEED

status=$?
echo "=========================================="
echo "Training finished with status $status"
echo "=========================================="
exit $status
