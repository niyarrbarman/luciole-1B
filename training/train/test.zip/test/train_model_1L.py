import argparse
import logging
import os
import sys
from pathlib import Path

import pytorch_lightning as pl
import torch
import fiddle

# Allow imports from the parent train package
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from recipes.recipe_utils import get_recipe  # noqa: E402
from utils import (  # noqa: E402
    check_tokenizer,
    process_datamix_file,
    save_config,
)

from nemo.lightning.io.mixin import IOMixin  # noqa: E402
from lightning.pytorch.callbacks import Callback  # noqa: E402


class GenerationCallback(Callback, IOMixin):
    """
    PyTorch Lightning callback to generate sample text during training.
    Runs on rank 0 only to avoid duplicated output.
    Inherits from IOMixin for NeMo/Fiddle compatibility.
    """

    def __init__(
        self,
        tokenizer,
        prompt: str = "The future of artificial intelligence is",
        every_n_steps: int = 100,
        max_new_tokens: int = 64,
        temperature: float = 0.7,
        top_k: int = 50,
    ):
        super().__init__()
        self.tokenizer = tokenizer
        self.prompt = prompt
        self.every_n_steps = every_n_steps
        self.max_new_tokens = max_new_tokens
        self.temperature = temperature
        self.top_k = top_k
        self._logger = logging.getLogger(__name__)

    @torch.no_grad()
    def _generate(self, model, device):
        """Generate text using the model with greedy/sampling decoding."""
        model.eval()

        # Tokenize input
        if hasattr(self.tokenizer, "text_to_ids"):
            input_ids = self.tokenizer.text_to_ids(self.prompt)
            input_ids = torch.tensor([input_ids], dtype=torch.long, device=device)
        else:
            inputs = self.tokenizer(self.prompt, return_tensors="pt")
            input_ids = inputs["input_ids"].to(device)

        generated_ids = input_ids.clone()

        # Get EOS token ID
        eos_id = getattr(self.tokenizer, "eos_id", None)
        if eos_id is None and hasattr(self.tokenizer, "eos_token_id"):
            eos_id = self.tokenizer.eos_token_id

        # Get the actual model module (NeMo wraps in self.module)
        if hasattr(model, "module") and model.module is not None:
            forward_model = model.module
        else:
            forward_model = model

        for step in range(self.max_new_tokens):
            seq_len = generated_ids.shape[1]
            position_ids = torch.arange(seq_len, dtype=torch.long, device=device).unsqueeze(0)
            attention_mask = torch.ones_like(generated_ids, device=device)

            try:
                outputs = forward_model(
                    input_ids=generated_ids,
                    position_ids=position_ids,
                    attention_mask=attention_mask,
                )
            except Exception as e:
                self._logger.warning(f"Generation forward failed: {e}")
                break

            # Get logits for the last token
            if hasattr(outputs, "logits"):
                next_token_logits = outputs.logits[:, -1, :].clone()
            elif isinstance(outputs, torch.Tensor):
                next_token_logits = outputs[:, -1, :].clone()
            else:
                next_token_logits = outputs[0][:, -1, :].clone()

            # Apply temperature
            if self.temperature > 0:
                next_token_logits = next_token_logits / self.temperature

            # Apply top-k filtering
            if self.top_k > 0:
                top_k_values, _ = torch.topk(
                    next_token_logits, min(self.top_k, next_token_logits.size(-1))
                )
                indices_to_remove = next_token_logits < top_k_values[..., -1, None]
                next_token_logits[indices_to_remove] = float("-inf")

            # Sample or greedy
            if self.temperature > 0:
                probs = torch.softmax(next_token_logits, dim=-1)
                next_token = torch.multinomial(probs, num_samples=1)
            else:
                next_token = torch.argmax(next_token_logits, dim=-1, keepdim=True)

            generated_ids = torch.cat([generated_ids, next_token], dim=-1)

            # Check for EOS
            if eos_id is not None and next_token.item() == eos_id:
                break

        # Decode
        if hasattr(self.tokenizer, "ids_to_text"):
            generated_text = self.tokenizer.ids_to_text(generated_ids[0].tolist())
        else:
            generated_text = self.tokenizer.decode(generated_ids[0], skip_special_tokens=True)

        model.train()
        return generated_text

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        """Generate sample text every N steps on rank 0."""
        if self.every_n_steps <= 0:
            return

        global_step = trainer.global_step
        if global_step % self.every_n_steps != 0:
            return

        # Only run on rank 0 to avoid duplicate output
        if trainer.global_rank != 0:
            return

        try:
            device = next(pl_module.parameters()).device
            generated_text = self._generate(pl_module, device)
            self._logger.info(f"\n{'='*60}")
            self._logger.info(f"[Step {global_step}] Generation sample:")
            self._logger.info(f"Prompt: {self.prompt}")
            self._logger.info(f"Output: {generated_text}")
            self._logger.info(f"{'='*60}\n")
        except Exception as e:
            self._logger.warning(f"Generation at step {global_step} failed: {e}")


def parse_args():
    parser = argparse.ArgumentParser(description="1-layer Nemotron training harness (test mode)")
    parser.add_argument(
        "--datamix",
        default="/tmpdir/m24047brmn/nemo_1b/data/nemo1b_mock_datamix.json",
        type=str,
        help="Path to datamix config (json/yaml).",
    )
    parser.add_argument("--arch", default="nemotron1b", type=str)
    parser.add_argument("--name", default="nemotron1b-1layer-test", type=str)
    parser.add_argument("--mode", default="debug", choices=["debug", "benchmark", "phase1", "phase2", "annealing"], type=str)
    parser.add_argument(
        "--output_dir",
        default="/tmpdir/m24047brmn/nemo_1b/output",
        type=str,
    )
    parser.add_argument("--batch_size", "--gbs", default=128, type=int)
    parser.add_argument("--micro_batch_size", "--mbs", default=1, type=int)
    parser.add_argument("--seq_length", default=1024, type=int)
    parser.add_argument("--tensor_parallelism", "--tp", default=1, type=int)
    parser.add_argument("--pipeline_parallelism", "--pp", default=1, type=int)
    parser.add_argument("--context_parallelism", "--cp", default=1, type=int)
    parser.add_argument("--max_steps", default=5000, type=int)
    parser.add_argument("--num_nodes", default=1, type=int)
    parser.add_argument("--gpus_per_node", default=1, type=int)
    parser.add_argument("--seed", default=1234, type=int)
    parser.add_argument("--base_checkpoint", default=None, type=str)
    parser.add_argument("--fp8", action="store_true", default=False)
    parser.add_argument("--performance_mode", action="store_true", default=False)
    # Generation during training
    parser.add_argument("--generate_every_n_steps", default=0, type=int,
                        help="Generate sample text every N steps (0 to disable)")
    parser.add_argument("--generate_prompt", default="The future of artificial intelligence is",
                        type=str, help="Prompt for generation during training")
    parser.add_argument("--generate_max_tokens", default=64, type=int,
                        help="Max tokens to generate during training")
    return parser.parse_args()


def main():
    args = parse_args()

    logging.basicConfig(stream=sys.stdout, level=logging.INFO)
    logger = logging.getLogger(__name__)

    torch.set_float32_matmul_precision("high")
    pl.seed_everything(args.seed, workers=True)

    # Build base recipe
    # Prefer CLI args over env vars for multi-node setup
    gpus_per_node = args.gpus_per_node
    num_nodes = args.num_nodes
    recipe_args = dict(
        dir=args.output_dir,
        name=args.name,
        num_nodes=num_nodes,
        num_gpus_per_node=gpus_per_node,
    )
    recipe = get_recipe(
        arch=args.arch,
        recipe_args=recipe_args,
        performance_mode_if_possible=args.performance_mode,
    )

    # Data setup
    tokenizer_name, data_paths, total_tokens = process_datamix_file(args.datamix)
    check_tokenizer(tokenizer_name, args.base_checkpoint)

    global_batch_size = args.batch_size
    seq_length = args.seq_length
    tokens_per_batch = seq_length * global_batch_size
    logger.info("Global batch size: %s", global_batch_size)
    logger.info("Sequence length: %s", seq_length)
    logger.info("Tokens per batch: %s", tokens_per_batch)
    logger.info("Total tokens in datamix: %s", total_tokens)

    from nemo import lightning as nl  # noqa: E402
    from nemo.collections.llm.gpt.data import PreTrainingDataModule  # noqa: E402
    from nemo.collections.nlp.modules.common.tokenizer_utils import get_tokenizer  # noqa: E402
    import nemo_run as run  # noqa: E402

    # -------------------------------------------------------------------------
    # Patch megatron.core.optimizer.get_megatron_optimizer to drop unsupported
    # kwargs that NeMo passes but older Megatron-Core versions do not accept.
    # We inspect the original function's signature and filter out any kwargs
    # that aren't in the accepted parameter list.
    # -------------------------------------------------------------------------
    try:
        import inspect
        import megatron.core.optimizer as mcore_optim  # type: ignore

        if not getattr(mcore_optim, "_patched_get_megatron_optimizer", False):
            _orig_get_megatron_optimizer = mcore_optim.get_megatron_optimizer
            # Get the accepted parameter names from the original function
            _orig_sig = inspect.signature(_orig_get_megatron_optimizer)
            _accepted_params = set(_orig_sig.parameters.keys())

            def _patched_get_megatron_optimizer(*args, **kwargs):
                # Filter kwargs to only those accepted by the original function
                filtered_kwargs = {k: v for k, v in kwargs.items() if k in _accepted_params}
                dropped = set(kwargs.keys()) - set(filtered_kwargs.keys())
                if dropped:
                    logger.debug("Dropped unsupported optimizer kwargs: %s", dropped)
                return _orig_get_megatron_optimizer(*args, **filtered_kwargs)

            mcore_optim.get_megatron_optimizer = _patched_get_megatron_optimizer
            mcore_optim._patched_get_megatron_optimizer = True
            logger.info("Patched megatron.core.optimizer.get_megatron_optimizer (accepted params: %s)", _accepted_params)
    except Exception as e:
        logger.warning("Could not patch megatron optimizer: %s", e)

    tokenizer = get_tokenizer(tokenizer_name=tokenizer_name, use_fast=True)

    data_args = dict(
        num_workers=8,
        pin_memory=True,
        split="1,0,0",
        paths=data_paths,
        global_batch_size=global_batch_size,
        micro_batch_size=args.micro_batch_size,
        seq_length=seq_length,
        seed=args.seed,
        index_mapping_dir=os.path.join(args.output_dir, "index_mapping"),
    )
    recipe.data = run.Config(PreTrainingDataModule, tokenizer=tokenizer, **data_args)

    # Model setup
    recipe.model.tokenizer = tokenizer
    recipe.model.config.seq_length = seq_length
    # Use the recipe's configured depth (full model) instead of forcing 1 layer.

    # Trainer setup
    recipe.trainer.max_steps = args.max_steps
    recipe.trainer.val_check_interval = args.max_steps
    recipe.trainer.limit_val_batches = 0.0
    recipe.trainer.log_every_n_steps = 1
    recipe.trainer.devices = gpus_per_node
    recipe.trainer.strategy.tensor_model_parallel_size = args.tensor_parallelism
    recipe.trainer.strategy.pipeline_model_parallel_size = args.pipeline_parallelism
    recipe.trainer.strategy.context_parallel_size = args.context_parallelism
    recipe.trainer.strategy.virtual_pipeline_model_parallel_size = None
    recipe.trainer.strategy.sequence_parallel = False
    recipe.trainer.strategy.pipeline_dtype = torch.bfloat16

    # Remove unsupported optimizer kwargs if present for this environment.
    optim_cfg = getattr(recipe, "optim", None)
    if optim_cfg and hasattr(optim_cfg, "config") and hasattr(optim_cfg.config, "no_weight_decay_cond"):
        try:
            delattr(optim_cfg.config, "no_weight_decay_cond")
        except Exception:
            pass

    # Callbacks and logging
    from nemo.lightning.pytorch.callbacks import GarbageCollectionCallback  # noqa: E402
    from nemo.lightning.pytorch.callbacks import ModelCheckpoint  # noqa: E402
    from callbacks import StatelessTimer  # noqa: E402

    callbacks_list = [
        # Lightning Timer expects DD:HH:MM:SS format; keep under 10h walltime.
        run.Config(StatelessTimer, duration="00:09:30:00"),
        run.Config(GarbageCollectionCallback, gc_interval_train=100, gc_interval_val=100),
        # Save checkpoints (weights) at end of training and every N steps
        run.Config(
            ModelCheckpoint,
            dirpath=os.path.join(args.output_dir, "checkpoints"),
            save_last=True,
            save_top_k=1,
            every_n_train_steps=500,  # save every 500 steps
            save_on_train_epoch_end=True,
            verbose=True,
        ),
    ]

    # Add generation callback if enabled
    if args.generate_every_n_steps > 0:
        callbacks_list.append(
            run.Config(
                GenerationCallback,
                tokenizer=tokenizer,
                prompt=args.generate_prompt,
                every_n_steps=args.generate_every_n_steps,
                max_new_tokens=args.generate_max_tokens,
                temperature=0.7,
                top_k=50,
            )
        )
        logger.info(f"Generation callback enabled: every {args.generate_every_n_steps} steps")

    recipe.trainer.callbacks = callbacks_list

    # Optimizer tweaks (keep defaults)
    recipe.optim.config.weight_decay = recipe.optim.config.weight_decay

    restore_config = (
        nl.RestoreConfig(path=args.base_checkpoint, load_optim_state=True)
        if args.base_checkpoint
        else None
    )
    recipe.resume = run.Config(
        nl.AutoResume,
        resume_if_exists=False,
        resume_ignore_no_checkpoint=True,
        resume_past_end=True,
        restore_config=restore_config,
    )

    # Save config snapshot
    job_id = os.environ.get("SLURM_JOB_ID", "0")
    job_output = os.path.join(args.output_dir, f"job_{job_id}")
    os.makedirs(job_output, exist_ok=True)
    save_config(job_output, args, recipe)

    # Build and run
    recipe_obj = fiddle.build(recipe)
    recipe_obj()

    logger.info("Finished 1-layer training run.")


if __name__ == "__main__":
    main()
